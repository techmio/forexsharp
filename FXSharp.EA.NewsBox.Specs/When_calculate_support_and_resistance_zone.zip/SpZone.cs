﻿namespace FXSharp.EA.NewsBox.Specs
{
    public class SpZone
    {
    }
}