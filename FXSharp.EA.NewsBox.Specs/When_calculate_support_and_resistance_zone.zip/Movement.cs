﻿namespace FXSharp.EA.NewsBox.Specs
{
    internal enum Movement
    {
        Up, Down, None
    }
}